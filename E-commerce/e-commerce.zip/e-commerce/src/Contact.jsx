function Contact(){
    return(
        <div style={{padding:"20px"}}>
            <h1>Contact Us</h1>
            <p>Email : support@store.com</p>
            <p>Phone : +91 9876543210</p>
        </div>
    )
}

export default Contact